# openWakeWord for Project Nora
## Jetson Orin Nano Super Implementation

Wake word detection system for autonomous robot with modern openWakeWord API (v0.6.0+).

## Features

- ✅ **Current API**: Uses latest openWakeWord (Feb 2024)
- ✅ **TFLite optimized**: Fast inference on Jetson ARM64
- ✅ **Pre-trained models**: "hey jarvis", "alexa", "hey mycroft", etc.
- ✅ **Noise suppression**: Optional Speex filtering
- ✅ **VAD integration**: Silero voice activity detection
- ✅ **Multi-threaded**: Non-blocking audio processing
- ✅ **State machine**: Robot state management (IDLE/LISTENING/PROCESSING)

## Quick Start

### 1. Installation

```bash
# Clone or download files, then run:
bash install_openwakeword.sh
```

This installs:
- `openwakeword` package
- PyAudio and dependencies
- Pre-trained wake word models
- Optional: Speex noise suppression

### 2. Basic Usage

```bash
# Test with default "hey jarvis" model
python3 nora_wakeword.py

# List available audio devices
python3 nora_wakeword.py --list_devices

# Use specific microphone
python3 nora_wakeword.py --device_index 1

# Enable noise suppression and VAD
python3 nora_wakeword.py --speex_noise_suppression --vad_threshold 0.5

# Adjust detection threshold
python3 nora_wakeword.py --threshold 0.7
```

### 3. Advanced Integration

For full robot integration with state management:

```bash
python3 nora_advanced_wakeword.py
```

This includes:
- Multi-threaded audio processing
- Robot state machine (IDLE → LISTENING → PROCESSING)
- Callback architecture for LED/Whisper integration
- Queue-based audio buffering

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   Audio Input (USB Mic)                 │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│              Audio Capture Thread                       │
│  • 16kHz mono PCM                                       │
│  • 1280 samples/chunk (80ms)                           │
│  • Non-blocking queue                                  │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│              Wake Word Detection                        │
│  • openWakeWord Model (TFLite)                         │
│  • Optional: Speex noise suppression                   │
│  • Optional: Silero VAD                                │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼ (if detected)
┌─────────────────────────────────────────────────────────┐
│              Robot Activation                           │
│  • LED eyes animation                                  │
│  • Whisper STT (5-10 sec)                             │
│  • Command processing                                  │
│  • Robot response                                      │
└─────────────────────────────────────────────────────────┘
```

## Pre-trained Models

Available models (download automatically):
- **hey_jarvis** - "Hey Jarvis" wake phrase
- **alexa** - "Alexa" wake word
- **hey_mycroft** - "Hey Mycroft" wake phrase
- **timer** - Timer/alarm phrases
- **weather** - Weather-related phrases

## Training Custom "Nora" Model

To train a custom "Nora" wake word:

### Option 1: Google Colab (Easiest)
1. Use official training notebook: https://colab.research.google.com/drive/1q1oe2zOyZp7UsB3jJiQ1IFn8z5YfjwEb
2. Follow prompts to generate synthetic data
3. Download resulting `.tflite` model
4. Use with: `python3 nora_wakeword.py --model_path /path/to/nora.tflite`

### Option 2: Local Training
```bash
# Clone openWakeWord repo
git clone https://github.com/dscripka/openWakeWord.git
cd openWakeWord

# Follow training notebook
jupyter notebook notebooks/automatic_model_training.ipynb
```

## Integration Examples

### Example 1: Simple Callback

```python
from nora_wakeword import NoraWakeWordDetector

def my_callback(model_name, score):
    print(f"Wake word detected: {model_name} ({score:.2f})")
    # Trigger LED animation
    # Start Whisper transcription
    # etc.

detector = NoraWakeWordDetector(threshold=0.5)
detector.start_stream()
detector.detect(callback=my_callback)
```

### Example 2: State Machine Integration

```python
from nora_advanced_wakeword import NoraWakeWordSystem

def on_wake(model_name, score):
    robot.led_eyes.animate("listening")
    whisper.start_recording()
    # Process voice command...
    wakeword_system.reset_to_idle()

wakeword_system = NoraWakeWordSystem(threshold=0.5)
wakeword_system.register_wake_callback(on_wake)
wakeword_system.start()
```

## Performance on Jetson Orin Nano

**Expected metrics** (based on Raspberry Pi benchmarks):
- **Latency**: 80-160ms detection
- **CPU usage**: 5-15% (single core)
- **Power**: ~0.5W additional
- **Throughput**: Can run 15-20 models simultaneously

With TFLite on Jetson, expect even better performance due to ARM optimizations.

## Microphone Recommendations

For mobile robot with good far-field detection:

1. **ReSpeaker 4-Mic Array** ($25)
   - USB interface
   - 4-mic beamforming
   - Far-field (3-5m range)
   - Good for noisy environments

2. **PlayStation Eye Camera** ($5-10 used)
   - 4-mic array
   - Budget option
   - USB 2.0
   - Decent quality

3. **USB Boundary Mic** ($15-30)
   - If operating in quiet lab environment
   - Simple integration

## Troubleshooting

### Audio Device Issues
```bash
# List devices
python3 nora_wakeword.py --list_devices

# Test specific device
arecord -D hw:1,0 -f S16_LE -r 16000 -c 1 test.wav
```

### Model Loading Errors
```python
# Verify model download
python3 -c "import openwakeword; openwakeword.utils.download_models()"

# Check models directory
ls ~/.openWakeWord/
```

### Low Detection Rate
- Lower threshold: `--threshold 0.3`
- Enable VAD: `--vad_threshold 0.5`
- Enable noise suppression: `--speex_noise_suppression`
- Check microphone positioning (2-3m max for basic USB mics)

### High False Positives
- Raise threshold: `--threshold 0.7`
- Enable VAD: `--vad_threshold 0.7`
- Train custom model with negative examples

## Files Included

- `nora_wakeword.py` - Basic wake word detection
- `nora_advanced_wakeword.py` - Full robot integration with threading
- `install_openwakeword.sh` - Installation script
- `requirements.txt` - Python dependencies
- `README.md` - This file

## Next Steps

1. **Install and test** with default model
2. **Integrate with LED controller** for visual feedback
3. **Connect to Whisper** for voice command processing
4. **Train custom "Nora" model** using Colab notebook
5. **Optimize threshold** for your environment
6. **Add to systemd** for auto-start on boot

## References

- openWakeWord GitHub: https://github.com/dscripka/openWakeWord
- Training Colab: https://colab.research.google.com/drive/1q1oe2zOyZp7UsB3jJiQ1IFn8z5YfjwEb
- JARVIS Jetson Project: https://github.com/steffenpharai/Jarvis
- Whisper for Jetson: https://github.com/openai/whisper

## License

openWakeWord: Apache 2.0
Pre-trained models: CC BY-NC-SA 4.0

---

**Epistemic confidence**: [Data: 90% | Secondary: 8% | Speculation: 2%]

Built for Project Nora - Autonomous Robot with Mecanum Wheels
