#!/usr/bin/env python3
"""
Advanced Wake Word Integration for Project Nora
Demonstrates integration with Whisper STT, LED control, and robot state machine
"""

import pyaudio
import numpy as np
from openwakeword.model import Model
import threading
import queue
import time
import logging
from enum import Enum
from typing import Callable, Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RobotState(Enum):
    """Robot operational states"""
    IDLE = "idle"
    LISTENING = "listening"  # Wake word detected, ready for command
    PROCESSING = "processing"  # Processing voice command
    RESPONDING = "responding"  # Executing response


class NoraWakeWordSystem:
    """
    Complete wake word system with state management
    Designed for integration with Project Nora
    """
    
    def __init__(
        self,
        model_paths=None,
        threshold=0.5,
        enable_noise_suppression=True,
        vad_threshold=0.5
    ):
        """
        Initialize Nora's wake word system
        
        Args:
            model_paths: Custom model paths or None for defaults
            threshold: Detection threshold
            enable_noise_suppression: Enable Speex filtering
            vad_threshold: Voice activity detection threshold
        """
        self.threshold = threshold
        self.state = RobotState.IDLE
        self.state_lock = threading.Lock()
        
        # Audio configuration
        self.FORMAT = pyaudio.paInt16
        self.CHANNELS = 1
        self.RATE = 16000
        self.CHUNK_SIZE = 1280  # 80ms at 16kHz
        
        # Threading components
        self.audio_queue = queue.Queue(maxsize=10)
        self.detection_thread = None
        self.running = False
        
        # Initialize model
        logger.info("Initializing wake word model...")
        self.model = Model(
            wakeword_models=model_paths,
            inference_framework='tflite',
            enable_speex_noise_suppression=enable_noise_suppression,
            vad_threshold=vad_threshold
        )
        
        logger.info(f"Loaded models: {list(self.model.models.keys())}")
        
        # Callbacks
        self.on_wake_word_callback = None
        self.on_state_change_callback = None
        
    def set_state(self, new_state: RobotState):
        """Thread-safe state change with callback"""
        with self.state_lock:
            old_state = self.state
            self.state = new_state
            logger.info(f"State: {old_state.value} -> {new_state.value}")
            
            if self.on_state_change_callback:
                self.on_state_change_callback(old_state, new_state)
    
    def register_wake_callback(self, callback: Callable[[str, float], None]):
        """Register callback for wake word detection"""
        self.on_wake_word_callback = callback
    
    def register_state_callback(self, callback: Callable[[RobotState, RobotState], None]):
        """Register callback for state changes"""
        self.on_state_change_callback = callback
    
    def _audio_capture_thread(self, audio_stream):
        """Continuously capture audio and queue for processing"""
        logger.info("Audio capture thread started")
        
        try:
            while self.running:
                # Only capture when in IDLE state
                with self.state_lock:
                    if self.state != RobotState.IDLE:
                        time.sleep(0.01)
                        continue
                
                # Read audio chunk
                try:
                    audio_data = np.frombuffer(
                        audio_stream.read(self.CHUNK_SIZE, exception_on_overflow=False),
                        dtype=np.int16
                    )
                    
                    # Non-blocking queue put
                    try:
                        self.audio_queue.put(audio_data, block=False)
                    except queue.Full:
                        # Drop frame if queue is full
                        pass
                        
                except Exception as e:
                    logger.error(f"Audio capture error: {e}")
                    time.sleep(0.1)
                    
        except Exception as e:
            logger.error(f"Audio thread fatal error: {e}", exc_info=True)
    
    def _detection_thread_func(self):
        """Process audio queue and detect wake words"""
        logger.info("Detection thread started")
        
        try:
            while self.running:
                try:
                    # Get audio from queue (with timeout)
                    audio_data = self.audio_queue.get(timeout=0.1)
                    
                    # Only detect when in IDLE state
                    with self.state_lock:
                        if self.state != RobotState.IDLE:
                            continue
                    
                    # Run detection
                    prediction = self.model.predict(audio_data)
                    
                    # Check for wake word
                    for model_name, score in prediction.items():
                        if score >= self.threshold:
                            logger.info(f"Wake word '{model_name}' detected! Score: {score:.3f}")
                            
                            # Change state to LISTENING
                            self.set_state(RobotState.LISTENING)
                            
                            # Trigger callback
                            if self.on_wake_word_callback:
                                threading.Thread(
                                    target=self.on_wake_word_callback,
                                    args=(model_name, score),
                                    daemon=True
                                ).start()
                            
                            # Clear queue to avoid processing stale audio
                            while not self.audio_queue.empty():
                                try:
                                    self.audio_queue.get_nowait()
                                except queue.Empty:
                                    break
                            
                            break  # Only trigger once per detection
                            
                except queue.Empty:
                    continue
                except Exception as e:
                    logger.error(f"Detection error: {e}", exc_info=True)
                    
        except Exception as e:
            logger.error(f"Detection thread fatal error: {e}", exc_info=True)
    
    def start(self, device_index=None):
        """Start wake word detection system"""
        if self.running:
            logger.warning("System already running")
            return
        
        logger.info("Starting Nora wake word system...")
        
        # Initialize audio
        audio = pyaudio.PyAudio()
        audio_stream = audio.open(
            format=self.FORMAT,
            channels=self.CHANNELS,
            rate=self.RATE,
            input=True,
            input_device_index=device_index,
            frames_per_buffer=self.CHUNK_SIZE
        )
        
        # Start threads
        self.running = True
        
        capture_thread = threading.Thread(
            target=self._audio_capture_thread,
            args=(audio_stream,),
            daemon=True
        )
        
        self.detection_thread = threading.Thread(
            target=self._detection_thread_func,
            daemon=True
        )
        
        capture_thread.start()
        self.detection_thread.start()
        
        logger.info("Wake word system active - listening for wake word...")
        self.set_state(RobotState.IDLE)
        
        # Keep main thread alive
        try:
            while self.running:
                time.sleep(0.5)
        except KeyboardInterrupt:
            logger.info("Shutting down...")
        finally:
            self.stop()
            audio_stream.stop_stream()
            audio_stream.close()
            audio.terminate()
    
    def stop(self):
        """Stop wake word detection system"""
        logger.info("Stopping wake word system...")
        self.running = False
        
        if self.detection_thread:
            self.detection_thread.join(timeout=2.0)
        
        logger.info("Wake word system stopped")
    
    def reset_to_idle(self):
        """Reset system to IDLE state (call after processing command)"""
        self.set_state(RobotState.IDLE)
        logger.info("Ready for next wake word")


# ============================================================================
# Example Integration with Robot Systems
# ============================================================================

class NoraRobotController:
    """Example robot controller integration"""
    
    def __init__(self):
        self.led_eyes_active = False
        self.whisper_active = False
    
    def trigger_led_animation(self, mode: str):
        """
        Trigger LED eye animation
        
        Args:
            mode: Animation mode ('listening', 'processing', 'responding')
        """
        logger.info(f"🔵 LED Animation: {mode}")
        # TODO: Implement actual LED controller communication
        # Example: send signal to LED controller via GPIO/I2C/serial
        self.led_eyes_active = True
    
    def start_voice_recognition(self):
        """Start Whisper STT for voice command"""
        logger.info("🎤 Starting Whisper voice recognition...")
        # TODO: Implement Whisper integration
        # Example: trigger Whisper transcription for 5-10 seconds
        self.whisper_active = True
    
    def stop_led_animation(self):
        """Stop LED animation"""
        logger.info("🔵 LED Animation stopped")
        self.led_eyes_active = False
    
    def execute_command(self, command: str):
        """Execute voice command"""
        logger.info(f"⚙️  Executing command: {command}")
        # TODO: Implement command execution


def on_wake_word_detected(model_name: str, score: float):
    """
    Callback when wake word is detected
    This is where you integrate with your robot systems
    """
    logger.info(f"\n{'='*60}")
    logger.info(f"  🤖 NORA ACTIVATED!")
    logger.info(f"  Model: {model_name}")
    logger.info(f"  Confidence: {score:.1%}")
    logger.info(f"{'='*60}\n")
    
    # Example integration with robot controller
    robot = NoraRobotController()
    
    # 1. Trigger LED eyes animation
    robot.trigger_led_animation("listening")
    
    # 2. Start voice recognition (Whisper)
    robot.start_voice_recognition()
    
    # 3. Process command (simulate)
    time.sleep(2)  # Simulate voice command processing
    
    # 4. Execute response
    robot.trigger_led_animation("processing")
    robot.execute_command("example_command")
    
    # 5. Reset to idle
    robot.stop_led_animation()
    wakeword_system.reset_to_idle()


def on_state_change(old_state: RobotState, new_state: RobotState):
    """Callback when robot state changes"""
    logger.debug(f"State transition: {old_state.value} -> {new_state.value}")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Advanced Nora Wake Word System')
    parser.add_argument('--threshold', type=float, default=0.5)
    parser.add_argument('--model_path', type=str, nargs='+', default=None)
    parser.add_argument('--device_index', type=int, default=None)
    args = parser.parse_args()
    
    # Initialize system
    wakeword_system = NoraWakeWordSystem(
        model_paths=args.model_path,
        threshold=args.threshold,
        enable_noise_suppression=True,
        vad_threshold=0.5
    )
    
    # Register callbacks
    wakeword_system.register_wake_callback(on_wake_word_detected)
    wakeword_system.register_state_callback(on_state_change)
    
    # Start system
    wakeword_system.start(device_index=args.device_index)
