#!/bin/bash
# Installation script for openWakeWord on Jetson Orin Nano Super
# For Project Nora

set -e  # Exit on error

echo "=================================================="
echo "openWakeWord Installation for Jetson Orin Nano"
echo "=================================================="

# Check if running on Jetson
if [ ! -f /etc/nv_tegra_release ]; then
    echo "Warning: This doesn't appear to be a Jetson device"
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Update system
echo -e "\n[1/6] Updating system packages..."
sudo apt update

# Install audio dependencies
echo -e "\n[2/6] Installing audio dependencies..."
sudo apt install -y \
    portaudio19-dev \
    python3-pyaudio \
    libasound2-dev \
    libspeexdsp-dev

# Install Python dependencies
echo -e "\n[3/6] Installing Python packages..."
pip3 install --upgrade pip
pip3 install \
    openwakeword \
    pyaudio \
    numpy

# Optional: Install Speex noise suppression (ARM64)
echo -e "\n[4/6] Installing Speex noise suppression (optional)..."
read -p "Install Speex noise suppression? (recommended, y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    # Try to install pre-built wheel for ARM64
    pip3 install https://github.com/dscripka/openWakeWord/releases/download/v0.1.1/speexdsp_ns-0.1.2-cp38-cp38-linux_aarch64.whl || \
    echo "Failed to install Speex wheel - you may need to build from source"
fi

# Download pre-trained models
echo -e "\n[5/6] Downloading pre-trained wake word models..."
python3 << EOF
import openwakeword
print("Downloading models...")
openwakeword.utils.download_models()
print("Models downloaded successfully!")
EOF

# Test installation
echo -e "\n[6/6] Testing installation..."
python3 << EOF
from openwakeword.model import Model
import numpy as np

print("Testing openWakeWord...")
model = Model(inference_framework='tflite')
print(f"Loaded models: {list(model.models.keys())}")

# Test prediction with dummy audio
dummy_audio = np.zeros(1280, dtype=np.int16)
prediction = model.predict(dummy_audio)
print("Test prediction successful!")
print("Available wake words:", list(prediction.keys()))
EOF

echo -e "\n=================================================="
echo "Installation complete!"
echo "=================================================="
echo ""
echo "Available pre-trained models:"
echo "  - alexa"
echo "  - hey_jarvis"
echo "  - hey_mycroft"
echo "  - timer"
echo "  - weather"
echo ""
echo "To test wake word detection:"
echo "  python3 nora_wakeword.py"
echo ""
echo "To list audio devices:"
echo "  python3 nora_wakeword.py --list_devices"
echo ""
echo "For custom 'Nora' wake word, see:"
echo "  https://colab.research.google.com/drive/1q1oe2zOyZp7UsB3jJiQ1IFn8z5YfjwEb"
echo ""
