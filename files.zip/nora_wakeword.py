#!/usr/bin/env python3
"""
Wake Word Detection for Project Nora using openWakeWord
Jetson Orin Nano Super implementation
"""

import pyaudio
import numpy as np
from openwakeword.model import Model
import argparse
import time
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class NoraWakeWordDetector:
    """Wake word detection system for Project Nora"""
    
    def __init__(
        self,
        model_paths=None,
        chunk_size=1280,
        threshold=0.5,
        inference_framework='tflite',
        enable_speex_noise_suppression=False,
        vad_threshold=None
    ):
        """
        Initialize wake word detector
        
        Args:
            model_paths: List of paths to .tflite model files, or None to load all defaults
            chunk_size: Audio samples per prediction (80ms chunks = 1280 samples at 16kHz)
            threshold: Detection threshold (0.0-1.0)
            inference_framework: 'tflite' (recommended for Jetson) or 'onnx'
            enable_speex_noise_suppression: Enable Speex noise filtering
            vad_threshold: Voice activity detection threshold (0.0-1.0), None to disable
        """
        self.chunk_size = chunk_size
        self.threshold = threshold
        
        # Audio configuration
        self.FORMAT = pyaudio.paInt16
        self.CHANNELS = 1
        self.RATE = 16000
        
        # Initialize audio interface
        self.audio = pyaudio.PyAudio()
        self.mic_stream = None
        
        # Initialize openWakeWord model
        logger.info("Initializing openWakeWord model...")
        logger.info(f"Inference framework: {inference_framework}")
        logger.info(f"Speex noise suppression: {enable_speex_noise_suppression}")
        logger.info(f"VAD threshold: {vad_threshold}")
        
        model_kwargs = {
            'inference_framework': inference_framework,
            'enable_speex_noise_suppression': enable_speex_noise_suppression,
        }
        
        if vad_threshold is not None:
            model_kwargs['vad_threshold'] = vad_threshold
            
        if model_paths:
            model_kwargs['wakeword_models'] = model_paths
            
        self.model = Model(**model_kwargs)
        
        logger.info(f"Loaded models: {list(self.model.models.keys())}")
        
    def list_audio_devices(self):
        """List available audio input devices"""
        logger.info("\nAvailable audio devices:")
        for i in range(self.audio.get_device_count()):
            info = self.audio.get_device_info_by_index(i)
            if info['maxInputChannels'] > 0:
                logger.info(f"  [{i}] {info['name']}")
                logger.info(f"      Channels: {info['maxInputChannels']}, Rate: {int(info['defaultSampleRate'])}")
    
    def start_stream(self, device_index=None):
        """Start microphone audio stream"""
        logger.info("Starting audio stream...")
        
        self.mic_stream = self.audio.open(
            format=self.FORMAT,
            channels=self.CHANNELS,
            rate=self.RATE,
            input=True,
            input_device_index=device_index,
            frames_per_buffer=self.chunk_size
        )
        
        logger.info("Audio stream started successfully")
    
    def stop_stream(self):
        """Stop microphone audio stream"""
        if self.mic_stream:
            self.mic_stream.stop_stream()
            self.mic_stream.close()
            logger.info("Audio stream stopped")
    
    def detect(self, callback=None):
        """
        Run wake word detection loop
        
        Args:
            callback: Function to call when wake word detected. 
                     Receives (model_name, score) as arguments.
        """
        if not self.mic_stream:
            raise RuntimeError("Audio stream not started. Call start_stream() first.")
        
        logger.info(f"\n{'='*60}")
        logger.info("WAKE WORD DETECTION ACTIVE")
        logger.info(f"Threshold: {self.threshold}")
        logger.info(f"Listening for: {list(self.model.models.keys())}")
        logger.info(f"{'='*60}\n")
        
        try:
            while True:
                # Read audio chunk
                audio_data = np.frombuffer(
                    self.mic_stream.read(self.chunk_size, exception_on_overflow=False),
                    dtype=np.int16
                )
                
                # Get predictions
                prediction = self.model.predict(audio_data)
                
                # Check for wake word detection
                for model_name, score in prediction.items():
                    if score >= self.threshold:
                        logger.info(f"\n🎯 WAKE WORD DETECTED: '{model_name}' (score: {score:.3f})")
                        
                        if callback:
                            callback(model_name, score)
                
        except KeyboardInterrupt:
            logger.info("\nDetection stopped by user")
        except Exception as e:
            logger.error(f"Error during detection: {e}", exc_info=True)
        finally:
            self.stop_stream()
    
    def cleanup(self):
        """Clean up resources"""
        self.stop_stream()
        self.audio.terminate()
        logger.info("Cleanup complete")


def on_wake_word_detected(model_name, score):
    """
    Callback function when wake word is detected
    
    This is where you'd trigger Nora's response:
    - Activate LED eyes animation
    - Start Whisper transcription
    - Send signal to robot controller
    """
    print(f"\n{'*'*60}")
    print(f"  NORA ACTIVATED!")
    print(f"  Model: {model_name}")
    print(f"  Confidence: {score:.1%}")
    print(f"{'*'*60}\n")
    
    # TODO: Add your robot activation logic here
    # Example:
    # led_controller.set_animation("listening")
    # whisper_stt.start_recording()
    # robot_controller.wake()


def main():
    parser = argparse.ArgumentParser(
        description='Wake Word Detection for Project Nora',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Use default "hey jarvis" model
  python nora_wakeword.py
  
  # Use custom model with VAD
  python nora_wakeword.py --model_path /path/to/nora.tflite --vad_threshold 0.5
  
  # Enable noise suppression
  python nora_wakeword.py --speex_noise_suppression
  
  # List audio devices
  python nora_wakeword.py --list_devices
        """
    )
    
    parser.add_argument(
        '--model_path',
        type=str,
        nargs='+',
        help='Path(s) to custom .tflite model file(s). Omit to use all defaults.'
    )
    
    parser.add_argument(
        '--threshold',
        type=float,
        default=0.5,
        help='Detection threshold (0.0-1.0). Default: 0.5'
    )
    
    parser.add_argument(
        '--chunk_size',
        type=int,
        default=1280,
        help='Audio chunk size in samples. Default: 1280 (80ms at 16kHz)'
    )
    
    parser.add_argument(
        '--inference_framework',
        type=str,
        default='tflite',
        choices=['tflite', 'onnx'],
        help='Inference framework. Default: tflite (recommended for Jetson)'
    )
    
    parser.add_argument(
        '--speex_noise_suppression',
        action='store_true',
        help='Enable Speex noise suppression (requires speexdsp installation)'
    )
    
    parser.add_argument(
        '--vad_threshold',
        type=float,
        default=None,
        help='Voice Activity Detection threshold (0.0-1.0). Reduces false positives.'
    )
    
    parser.add_argument(
        '--device_index',
        type=int,
        default=None,
        help='Audio input device index. See --list_devices'
    )
    
    parser.add_argument(
        '--list_devices',
        action='store_true',
        help='List available audio input devices and exit'
    )
    
    args = parser.parse_args()
    
    # Initialize detector
    detector = NoraWakeWordDetector(
        model_paths=args.model_path,
        chunk_size=args.chunk_size,
        threshold=args.threshold,
        inference_framework=args.inference_framework,
        enable_speex_noise_suppression=args.speex_noise_suppression,
        vad_threshold=args.vad_threshold
    )
    
    # List devices if requested
    if args.list_devices:
        detector.list_audio_devices()
        return
    
    # Start detection
    try:
        detector.start_stream(device_index=args.device_index)
        detector.detect(callback=on_wake_word_detected)
    finally:
        detector.cleanup()


if __name__ == "__main__":
    main()
